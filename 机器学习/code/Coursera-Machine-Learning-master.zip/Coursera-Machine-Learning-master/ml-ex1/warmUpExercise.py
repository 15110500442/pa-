import numpy as np

#WARMUPEXERCISE Example function in python
#   warmUpExercise() is an example function that returns the 5x5 identity matrix
def warmUpExercise():
    
    A = np.identity(5)

    return A